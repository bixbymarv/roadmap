A brief overview of how Omaha works is provided [here](OmahaOverview.html):

The document describes the rationale of the project, some of the high level requirements, and the high level design.
