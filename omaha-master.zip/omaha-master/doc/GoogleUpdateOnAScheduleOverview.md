A brief overview of GoogleUpdate.exe on a Schedule is provided [here](GoogleUpdateOnAScheduleOverview.html).

The document describes the background behind the changes, some of the high level requirements, and the high level design.
